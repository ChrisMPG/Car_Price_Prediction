-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`Wishlist`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Wishlist` (
  `idWishlist` INT AUTO_INCREMENT,
  `preco_Total` DECIMAL(2) NULL,
  PRIMARY KEY (`idWishlist`),
  UNIQUE INDEX `idWishlist_UNIQUE` (`idWishlist` ASC) VISIBLE)
ENGINE = InnoDB;



-- -----------------------------------------------------
-- Table `mydb`.`Produto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Produto` (
  `idProduto` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(50) NOT NULL,
  `descricao` VARCHAR(100) NULL,
  `tamanhos_Disponiveis` ENUM('XS', 'S', 'M','L','XL', 'TODOS') NULL,
  `preco` DECIMAL(2) UNSIGNED NOT NULL,
  PRIMARY KEY (`idProduto`),
  UNIQUE INDEX `idProduto_UNIQUE` (`idProduto` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Cliente`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Cliente` (
  `cc` INT UNSIGNED NOT NULL,
  `email` VARCHAR(90) NOT NULL,
  `nome` VARCHAR(100) NOT NULL,
  `NIF` INT NOT NULL,
  `rua` VARCHAR(75) NOT NULL,
  `numero_Porta` INT NOT NULL,
  `codigo_Postal` VARCHAR(8) NOT NULL,
  `concelho` VARCHAR(60) NOT NULL,
  `distrito` VARCHAR(60) NOT NULL,
  `Wishlist_idWishlist` INT NOT NULL,
  PRIMARY KEY (`cc`),
  UNIQUE INDEX `cc_UNIQUE` (`cc` ASC) VISIBLE,
  UNIQUE INDEX `email_UNIQUE` (`email` ASC) VISIBLE,
  UNIQUE INDEX `NIF_UNIQUE` (`NIF` ASC) VISIBLE,
  INDEX `fk_Cliente_Wishlist1_idx` (`Wishlist_idWishlist` ASC) VISIBLE,
  CONSTRAINT `fk_Cliente_Wishlist1`
    FOREIGN KEY (`Wishlist_idWishlist`)
    REFERENCES `mydb`.`Wishlist` (`idWishlist`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`MetodoPagamento`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`MetodoPagamento` (
  `idMetodoPagamento` INT NOT NULL AUTO_INCREMENT,
  `forma_Pagamento` ENUM('PAYPAL', 'BITCOIN', 'MASTERCARD', 'VISA', 'TRANSF') NOT NULL,
  `Cliente_cc` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`idMetodoPagamento`),
  UNIQUE INDEX `idMetodoPagamento_UNIQUE` (`idMetodoPagamento` ASC) VISIBLE,
  INDEX `fk_MetodoPagamento_Cliente1_idx` (`Cliente_cc` ASC) VISIBLE,
  CONSTRAINT `fk_MetodoPagamento_Cliente1`
    FOREIGN KEY (`Cliente_cc`)
    REFERENCES `mydb`.`Cliente` (`cc`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Encomenda`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Encomenda` (
  `idEncomenda` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `data_Envio` DATETIME NOT NULL,
  `preco_Total` DECIMAL(2) UNSIGNED NOT NULL,
  `MetodoPagamento_idMetodoPagamento` INT NOT NULL,
  PRIMARY KEY (`idEncomenda`),
  UNIQUE INDEX `idEncomenda_UNIQUE` (`idEncomenda` ASC) VISIBLE,
  INDEX `fk_Encomenda_MetodoPagamento1_idx` (`MetodoPagamento_idMetodoPagamento` ASC) VISIBLE,
  CONSTRAINT `fk_Encomenda_MetodoPagamento1`
    FOREIGN KEY (`MetodoPagamento_idMetodoPagamento`)
    REFERENCES `mydb`.`MetodoPagamento` (`idMetodoPagamento`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Fatura`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Fatura` (
  `idFatura` INT NOT NULL AUTO_INCREMENT,
  `data_Processamento` DATETIME NOT NULL,
  `data_Envio` DATETIME NOT NULL,
  `data_Prevista_Chegada` DATETIME NULL,
  `preco_Total` DECIMAL(2) NOT NULL,
  `rua` VARCHAR(75) NOT NULL,
  `numero_Porta` INT NOT NULL,
  `codigo_Postal` VARCHAR(8) NOT NULL,
  `concelho` VARCHAR(60) NOT NULL,
  `distrito` VARCHAR(60) NOT NULL,
  `Cliente_cc` INT UNSIGNED NOT NULL,
  `Encomenda_idEncomenda` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`idFatura`),
  UNIQUE INDEX `idFatura_UNIQUE` (`idFatura` ASC) VISIBLE,
  INDEX `fk_Fatura_Cliente1_idx` (`Cliente_cc` ASC) VISIBLE,
  INDEX `fk_Fatura_Encomenda1_idx` (`Encomenda_idEncomenda` ASC) VISIBLE,
  CONSTRAINT `fk_Fatura_Cliente1`
    FOREIGN KEY (`Cliente_cc`)
    REFERENCES `mydb`.`Cliente` (`cc`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Fatura_Encomenda1`
    FOREIGN KEY (`Encomenda_idEncomenda`)
    REFERENCES `mydb`.`Encomenda` (`idEncomenda`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Cliente_contactos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Cliente_contactos` (
  `contactos` INT NOT NULL,
  `Cliente_cc` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`contactos`),
  INDEX `fk_Cliente_contactos_Cliente_idx` (`Cliente_cc` ASC) VISIBLE,
  CONSTRAINT `fk_Cliente_contactos_Cliente`
    FOREIGN KEY (`Cliente_cc`)
    REFERENCES `mydb`.`Cliente` (`cc`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Wishlist_has_Produto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Wishlist_has_Produto` (
  `Wishlist_idWishlist` INT NOT NULL,
  `Produto_idProduto` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`Wishlist_idWishlist`, `Produto_idProduto`),
  INDEX `fk_Wishlist_has_Produto_Produto1_idx` (`Produto_idProduto` ASC) VISIBLE,
  INDEX `fk_Wishlist_has_Produto_Wishlist1_idx` (`Wishlist_idWishlist` ASC) VISIBLE,
  CONSTRAINT `fk_Wishlist_has_Produto_Wishlist1`
    FOREIGN KEY (`Wishlist_idWishlist`)
    REFERENCES `mydb`.`Wishlist` (`idWishlist`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Wishlist_has_Produto_Produto1`
    FOREIGN KEY (`Produto_idProduto`)
    REFERENCES `mydb`.`Produto` (`idProduto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Produto_has_Encomenda`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Produto_has_Encomenda` (
  `Produto_idProduto` INT UNSIGNED NOT NULL,
  `Encomenda_idEncomenda` INT UNSIGNED NOT NULL,
  `preco_unitario` DECIMAL(2) UNSIGNED NOT NULL,
  `quantidade` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`Produto_idProduto`, `Encomenda_idEncomenda`),
  INDEX `fk_Produto_has_Encomenda_Encomenda1_idx` (`Encomenda_idEncomenda` ASC) VISIBLE,
  INDEX `fk_Produto_has_Encomenda_Produto1_idx` (`Produto_idProduto` ASC) VISIBLE,
  CONSTRAINT `fk_Produto_has_Encomenda_Produto1`
    FOREIGN KEY (`Produto_idProduto`)
    REFERENCES `mydb`.`Produto` (`idProduto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Produto_has_Encomenda_Encomenda1`
    FOREIGN KEY (`Encomenda_idEncomenda`)
    REFERENCES `mydb`.`Encomenda` (`idEncomenda`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Produto_has_Fatura`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Produto_has_Fatura` (
  `Produto_idProduto` INT UNSIGNED NOT NULL,
  `Fatura_idFatura` INT NOT NULL,
  `preco_unitario` DECIMAL(2) UNSIGNED NOT NULL,
  `quantidade` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`Produto_idProduto`, `Fatura_idFatura`),
  INDEX `fk_Produto_has_Fatura_Fatura1_idx` (`Fatura_idFatura` ASC) VISIBLE,
  INDEX `fk_Produto_has_Fatura_Produto1_idx` (`Produto_idProduto` ASC) VISIBLE,
  CONSTRAINT `fk_Produto_has_Fatura_Produto1`
    FOREIGN KEY (`Produto_idProduto`)
    REFERENCES `mydb`.`Produto` (`idProduto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Produto_has_Fatura_Fatura1`
    FOREIGN KEY (`Fatura_idFatura`)
    REFERENCES `mydb`.`Fatura` (`idFatura`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
