use mydb;

#Consultas

# 1 – Apresentar o(s) nome(s) do(s) cliente(s) em que o respetivo e-mail inicie com a letra “m” e que tenha realizado uma compra no dia 25-12-2020

Select nome, email, cc, Cliente_cc, data_processamento 
From Cliente c, Fatura f
Where email like 'm%' and cc.c = Cliente_cc.f and data_processamento = ‘2020-12-25’
Group by nome, email, data_processamento
Order by data_processamento

# 2 – Selecionar o nome dos clientes que possuem mais do que um contacto registado

Select nome, cc, Cliente_cc, Count(contactos)
From Cliente c, Cliente_contactos cca
Having cc.c = Cliente_cc.cca and Count(contactos)>1
Group by nome

# 3 – Listar os produtos disponíveis de forma crescente por preço (do mais barato para o mais caro).

Select nome, preco
From Produto
Group by nome
Order by preco ASC

# 4 – Ordenar de forma decrescente os produtos mais vendidos.

Select Count(id), nome
From Encomenda
Group by nome, id
Order by Count(id) DESC

# 5 – Exibir o(s) nome(s) do(s) cliente(s) que vive(m) no distrito do "Algarve"

Select nome, distrito
From Cliente
Where distrito = "Algarve"