use mydb;


Insert into Wishlist 
(preco_Total)
values
(19.99),
(14.99),
(29.99),
(14.90);


Insert into Cliente
(cc, email, nome, NIF, rua, numero_Porta, codigo_Postal, concelho, distrito, Wishlist_idWishlist)
values
(12345678, "marco_horacio@estg.ipp.pt", "Marco", 235093476, "Rua dos sapatos",223,"4459-365","A aldeia", "Setubal", 1),
(87654321, "hor4cio_coubes2@estg.ipp.pt", "Marcio", 127746161, "Rua das Coubes",22,"4461-045","Sopinha de massa", "Viana do Castelo", 2),
(65478123, "comerciante_de_lacticinios@estg.ipp.pt", "André", 321444123, "Rua do comércio",350,"2590-665","Chiado", "Lisboa", 3),
(46587123, "o_binglada83@estg.ipp.pt", "António", 132456789, "Rua dos portões",840,"6541-053","Principado da pontinha", "Algarve", 4);


  Insert into Cliente_contactos
  (contactos, Cliente_cc)
  values
  (916331410, 12345678),
  (935648762, 12345678),
  (961612411, 87654321),
  (921112400, 65478123),
  (938110467, 65478123),
  (964598324, 65478123),
  (954375684, 46587123);
  
  
  Insert into Produto
  (nome, descricao, tamanhos_Disponiveis, preco)
  values
  ("Mike watermin", "Camisolas de corrida e bonitas.", 'TODOS', 19.99),
  ("Style Shirt", "Camisola para estilo muita fixe.", 'TODOS', 29.99),
  ("MELÕES LEVES", "Camisola com desenhos estilo cartoon de melões a flutuar.", 'TODOS', 15.00),
  ("Mini Polo", "Polo pequeno para criança.", 'XS', 15.00),
  ("GYM Caviada M", "Camsiola caviada dedicada para desporto e ginásio.", 'M', 14.90);


  Insert into Fatura
  (data_Processamento, data_Envio, data_Prevista_Chegada, preco_Total, rua, numero_Porta, codigo_Postal, concelho, distrito, Cliente_cc)
  values
  (2020-10-22, 2020-10-23, 2020-10-27, "Rua dos sapatos", 223,"4459-365","A aldeia", "Setubal", 12345678),
  (202-10-25, 2020-10-25, 2020-10-30, "Rua das Coubes",  22 ,"4461-045","Sopinha de massa", "Viana do Castelo", 87654321),
  (2020-12-25, 2020-12-25, 2021-01-02, "Rua do comércio",350,"2590-665","Chiado", "Lisboa", 65478123),
  (2021-01-03, 2021-01-04, 2021-01-10, "Rua dos portões",840,"6541-053","Principado da pontinha", "Algarve", 46587123),
  (2021-02-08, 2021-02-09, 2021-02-19, "Rua dos portões",840,"6541-053","Principado da pontinha", "Algarve", 46587123),
  (2021-02-12, 2021-02-12, 2021-02-20, "Rua dos sapatos", 223,"4459-365","A aldeia", "Setubal", 12345678);


  Insert into MetodoPagamento
  (forma_Pagamento, Cliente_cc)
  values
  ('PAYPAL', 12345678),
  ('BITCOIN', 12345678),
  ('PAYPAL', 87654321),
  ('VISA', 87654321),
  ('VISA', 65478123),
  ('BITCOIN', 65478123),
  ('MASTERCARD', 46587123);
  
  
  Insert into Encomenda
  (idEncomenda, data_Envio, preco_Total, MetodoPagamento_idMetodoPagamento)
  values
  (1, 2020-10-23, 39.98, 1),
  (2, 2020-10-25, 29.99, 1),
  (3, 2020-12-25, 15.00, 3),
  (4, 2021-01-04, 14.90, 4),
  (5, 2021-02-09, 19.99, 5),
  (6, 2021-02-12, 90.00, 6);


Insert into Fatura_has_Produto
(Produto_idProduto, Fatura_idFatura, preco_unitario, quantidade)
values
(1,1,19.99,2),
(2,2,29.99,1),
(3,3,15.00,5),
(5,4,14.90,1),
(1,5,19.99,1),
(4,6,15.00,6);


  Insert into Produto_has_Encomenda
  (Produto_idProduto, Fatura_idFatura, preco_unitario, quantidade)
  values
(1,1,19.99,2),
(2,2,29.99,1),
(3,3,15.00,5),
(5,4,14.90,1),
(1,5,19.99,1),
(4,6,15.00,6);